package com.flycast.emulator;

import android.Manifest;
import android.annotation.SuppressLint;
import android.graphics.Bitmap;
import android.os.SystemClock;
import android.view.PixelCopy;
import android.view.SurfaceView;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.InputDevice;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewConfiguration;
import android.view.Window;
import android.view.WindowManager;
import android.widget.ImageView;
import android.window.OnBackInvokedDispatcher;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;

import com.flycast.emulator.config.Config;
import com.flycast.emulator.emu.AudioBackend;
import com.flycast.emulator.emu.HttpClient;
import com.flycast.emulator.emu.JNIdc;
import com.flycast.emulator.periph.InputDeviceManager;
import com.flycast.emulator.periph.SipEmulator;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static android.content.res.Configuration.HARDKEYBOARDHIDDEN_NO;
import static android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
import static android.view.WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS;
import static android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION;
import static android.view.WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS;

public abstract class BaseGLActivity extends Activity implements ActivityCompat.OnRequestPermissionsResultCallback {
    private static final int STORAGE_PERM_REQUEST = 1001;
    private static final int AUDIO_PERM_REQUEST = 1002;

    protected SharedPreferences prefs;
    private AudioBackend audioBackend;
    protected Handler handler = new Handler();
    private boolean audioPermissionRequested = false;
    private boolean storagePermissionGranted = false;
    private boolean paused = true;
    private boolean userPaused = false;
    public HudOverlay hud;
    private boolean resumedCalled = false;
    private String pendingIntentUrl;
    private boolean hasKeyboard = false;
    private AndroidStorage storage;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        if (!(getApplicationContext() instanceof Emulator)) {
            // app is in restricted mode, kill it
            // See https://medium.com/@pablobaxter/what-happened-to-my-subclass-android-application-924c91bafcac
            handler.post(() -> System.exit(0));
            finish();
            return;
        }
        // Set the navigation bar color to 0 to avoid left over when it fades out on Android 10
        Window window = getWindow();
        window.addFlags(FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        window.clearFlags(FLAG_TRANSLUCENT_STATUS | FLAG_TRANSLUCENT_NAVIGATION);
        window.setNavigationBarColor(0);
        window.getDecorView().setSystemUiVisibility(SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            getWindow().getAttributes().layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
        }

        if (!getFilesDir().exists()) {
            getFilesDir().mkdir();
        }
        prefs = PreferenceManager.getDefaultSharedPreferences(this);

        Emulator.setCurrentActivity(this);
        new HttpClient().nativeInit();

        String homeDir = prefs.getString(Config.pref_home, "");
        // Check that home dir is valid
        if (homeDir.isEmpty()) {
            // home dir not set: use default
            homeDir = getDefaultHomeDir();
            prefs.edit().putString(Config.pref_home, homeDir).apply();
        }

        String result = JNIdc.initEnvironment((Emulator)getApplicationContext(), getFilesDir().getAbsolutePath(), homeDir,
                Locale.getDefault().toString());
        if (result != null) {
            showAlertDialog(result);
            return;
        }
        Log.i("flycast", "Environment initialized");
        Emulator app = (Emulator)getApplicationContext();
        app.getConfigurationPrefs();
        storage = new AndroidStorage(this);
        setStorageDirectories();

        boolean externalStorageLegacy = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            externalStorageLegacy = Environment.isExternalStorageLegacy();
            //Log.i("flycast", "External storage legacy: " + (externalStorageLegacy ? "preserved" : "lost"));
        }
        if (!storagePermissionGranted) {
            if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M || !externalStorageLegacy)
                // No permission needed before Android 6
                // Permissions only needed in legacy external storage mode
                storagePermissionGranted = true;
            else {
                Log.i("flycast", "Asking for external storage permission");
                ActivityCompat.requestPermissions(this,
                        new String[]{
                                Manifest.permission.READ_EXTERNAL_STORAGE,
                                Manifest.permission.WRITE_EXTERNAL_STORAGE
                        },
                        STORAGE_PERM_REQUEST);
            }
        }

        Log.i("flycast", "Initializing input devices");
        InputDeviceManager.getInstance().startListening(getApplicationContext());
        register(this);
        audioBackend = new AudioBackend();
        onConfigurationChanged(getResources().getConfiguration());

        // Back button handling on Android 13+
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            getOnBackInvokedDispatcher().registerOnBackInvokedCallback(OnBackInvokedDispatcher.PRIORITY_DEFAULT, () -> {
                onBackKey();
            });
        }

        // When viewing a resource, pass its URI to the native code for opening
        Intent intent = getIntent();
        boolean gameFromIntent = false;
        if (Intent.ACTION_VIEW.equals(intent.getAction())) {
            Uri gameUri = intent.getData();
            // Flush the intent to prevent multiple calls
            getIntent().setData(null);
            setIntent(null);
            if (gameUri != null) {
                gameFromIntent = true;
                if (storagePermissionGranted)
                    JNIdc.setGameUri(gameUri.toString());
                else
                    pendingIntentUrl = gameUri.toString();
            }
        }
        if (!gameFromIntent)
            autoBoot(homeDir);
        Log.i("flycast", "BaseGLActivity.onCreate done");
    }

	// Called from native code
    public void showAlertDialog(String message)
    {
        handler.post(new Runnable() {
            @Override
            public void run() {
                AlertDialog.Builder dlgAlert = new AlertDialog.Builder(BaseGLActivity.this);
                dlgAlert.setMessage(getResources().getString(R.string.init_failed_message) + message);
                dlgAlert.setTitle(R.string.flycast_error);
                dlgAlert.setPositiveButton(R.string.exit,
                        new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int id) {
                                BaseGLActivity.this.finish();
                            }
                        });
                dlgAlert.setIcon(android.R.drawable.ic_dialog_alert);
                dlgAlert.setCancelable(false);
                dlgAlert.create().show();
            }
        });
    }

    private void setStorageDirectories()
    {
        String android_home_directory = Environment.getExternalStorageDirectory().getAbsolutePath();
        List<String> pathList = new ArrayList<>();
        pathList.add(android_home_directory);
        pathList.addAll(FileBrowser.getExternalMounts());
        pathList.add(getApplicationContext().getFilesDir().getAbsolutePath());
        File dir= getApplicationContext().getExternalFilesDir(null);
        if (dir != null)
            pathList.add(dir.getAbsolutePath());
        Log.i("flycast", "Storage dirs: " + pathList);
        if (storage != null)
            storage.setStorageDirectories(pathList);
        JNIdc.setExternalStorageDirectories(pathList.toArray());
    }

    // Testing
    public AndroidStorage getStorage() {
        return storage;
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        paused = true;
        InputDeviceManager.getInstance().stopListening();
        register(null);
        if (audioBackend != null)
            audioBackend.release();
        if (hud != null)
            hud.destroy();
        Emulator.setCurrentActivity(null);
        stopEmulator();
    }

    @Override
    protected void onPause() {
        super.onPause();
        resumedCalled = false;
        handleStateChange(true);
    }

    @Override
    protected void onResume() {
        super.onResume();
        resumedCalled = true;
        handleStateChange(false);
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) {
            handleStateChange(false);
        } else {
            handleStateChange(true);
        }
    }

    @Override
    public void onConfigurationChanged(@NonNull Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        hasKeyboard = newConfig.hardKeyboardHidden == HARDKEYBOARDHIDDEN_NO;
    }

    protected abstract void doPause();
    protected abstract void doResume();
    protected abstract boolean isSurfaceReady();

    public boolean toggleUserPause()
    {
        userPaused = !userPaused;
        handleStateChange(userPaused);
        return userPaused;
    }

    public void handleStateChange(boolean paused)
    {
        if (!paused && userPaused)
            return;
        if (paused == this.paused)
            return;
        if (!paused && (!resumedCalled || !isSurfaceReady()))
            return;
        this.paused = paused;
        if (paused) {
            doPause();
        }
        else {
            doResume();
        }
    }

    private boolean showMenu() {
        if (hud != null && !JNIdc.guiIsOpen())
            hud.showQuickOptions();
        else
            JNIdc.guiOpenSettings();
        return true;
    }

    private boolean processJoystickInput(MotionEvent event, InputDevice.MotionRange range) {
        float v = event.getAxisValue(range.getAxis(), event.getActionIndex());
        // normalize to [-32768, 32767]
        v = (v - range.getMin()) / range.getRange() * 65535.f - 32768.f;
        return InputDeviceManager.getInstance().axisEvent(event.getDeviceId(), range.getAxis(), (int)Math.round(v));
    }
    @Override
    public boolean onGenericMotionEvent(MotionEvent event) {
        InputDeviceManager deviceManager = InputDeviceManager.getInstance();
        if ((event.getSource() & InputDevice.SOURCE_CLASS_JOYSTICK) == InputDevice.SOURCE_CLASS_JOYSTICK
                && event.getAction() == MotionEvent.ACTION_MOVE
                && event.getDevice() != null)
        {
            List<InputDevice.MotionRange> axes = event.getDevice().getMotionRanges();
            boolean rc = false;
            int actionPointerIndex = event.getActionIndex();
            for (InputDevice.MotionRange range : axes)
            {
                if ((range.getSource() & InputDevice.SOURCE_CLASS_MASK) != InputDevice.SOURCE_CLASS_JOYSTICK)
		            // Ignore mouse/touchpad axes (dualshock 4)
		            continue;
                if (range.getAxis() == MotionEvent.AXIS_HAT_X) {
                    float v = event.getAxisValue(MotionEvent.AXIS_HAT_X, actionPointerIndex);
                    if (v == -1.0) {
                        rc |= deviceManager.buttonEvent(event.getDeviceId(), KeyEvent.KEYCODE_DPAD_LEFT, true);
                        deviceManager.buttonEvent(event.getDeviceId(), KeyEvent.KEYCODE_DPAD_RIGHT, false);
                    }
                    else if (v == 1.0) {
                        deviceManager.buttonEvent(event.getDeviceId(), KeyEvent.KEYCODE_DPAD_LEFT, false);
                        rc |= deviceManager.buttonEvent(event.getDeviceId(), KeyEvent.KEYCODE_DPAD_RIGHT, true);
                    } else {
                        deviceManager.buttonEvent(event.getDeviceId(), KeyEvent.KEYCODE_DPAD_LEFT, false);
                        deviceManager.buttonEvent(event.getDeviceId(), KeyEvent.KEYCODE_DPAD_RIGHT, false);
                    }
                }
                else if (range.getAxis() == MotionEvent.AXIS_HAT_Y) {
                    float v = event.getAxisValue(MotionEvent.AXIS_HAT_Y, actionPointerIndex);
                    if (v == -1.0) {
                        rc |= deviceManager.buttonEvent(event.getDeviceId(), KeyEvent.KEYCODE_DPAD_UP, true);
                        deviceManager.buttonEvent(event.getDeviceId(), KeyEvent.KEYCODE_DPAD_DOWN, false);
                    }
                    else if (v == 1.0) {
                        deviceManager.buttonEvent(event.getDeviceId(), KeyEvent.KEYCODE_DPAD_UP, false);
                        rc |= deviceManager.buttonEvent(event.getDeviceId(), KeyEvent.KEYCODE_DPAD_DOWN, true);
                    } else {
                        deviceManager.buttonEvent(event.getDeviceId(), KeyEvent.KEYCODE_DPAD_UP, false);
                        deviceManager.buttonEvent(event.getDeviceId(), KeyEvent.KEYCODE_DPAD_DOWN, false);
                    }
                }
                else {
                    rc |= processJoystickInput(event, range);
                }
            }
            if (rc)
                return true;
        }
        else if ((event.getSource() & InputDevice.SOURCE_CLASS_POINTER) == InputDevice.SOURCE_CLASS_POINTER) {
            switch (event.getAction()) {
                case MotionEvent.ACTION_SCROLL:
                    deviceManager.mouseScrollEvent(Math.round(-event.getAxisValue(MotionEvent.AXIS_VSCROLL)));
                    break;
                default:
                    deviceManager.mouseEvent(Math.round(event.getX()), Math.round(event.getY()), event.getButtonState());
                    break;
            }
            return true;
        }
        return super.onGenericMotionEvent(event);
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        if (InputDeviceManager.getInstance().buttonEvent(event.getDeviceId(), keyCode, false))
            return true;
        if (hasKeyboard && InputDeviceManager.getInstance().keyboardEvent(keyCode, false))
            return true;
        return super.onKeyUp(keyCode, event);
    }

    private void onBackKey() {
        if (JNIdc.guiIsContentBrowser()) {
            finish();
        }
        else {
            showMenu();
        }
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (event.getRepeatCount() == 0) {
            if (keyCode == KeyEvent.KEYCODE_BACK) {
                onBackKey();
                return true;
            }
            InputDeviceManager deviceManager = InputDeviceManager.getInstance();
            if (deviceManager.buttonEvent(event.getDeviceId(), keyCode, true))
                return true;

            if (hasKeyboard) {
                deviceManager.keyboardEvent(keyCode, true);
                if (!event.isCtrlPressed() && (event.isPrintingKey() || event.getKeyCode() == KeyEvent.KEYCODE_SPACE))
                    deviceManager.keyboardText(event.getUnicodeChar());
                return true;
            }
            if (ViewConfiguration.get(this).hasPermanentMenuKey()) {
                if (keyCode == KeyEvent.KEYCODE_MENU) {
                    return showMenu();
                }
            }
        }
        return super.onKeyDown(keyCode, event);
    }

    protected void stopEmulator() {
        JNIdc.stop();
    }

    void requestRecordAudioPermission() {
        if (audioPermissionRequested)
            return;
        audioPermissionRequested = true;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            handler.post(new Runnable() {
                @Override
                public void run() {
                    Log.i("flycast", "Requesting Record audio permission");
                    ActivityCompat.requestPermissions(BaseGLActivity.this,
                            new String[]{
                                    Manifest.permission.RECORD_AUDIO
                            },
                            AUDIO_PERM_REQUEST);

                }
            });
        }
        else
        {
            onRequestPermissionsResult(AUDIO_PERM_REQUEST, new String[] { Manifest.permission.RECORD_AUDIO },
                    new int[] { PackageManager.PERMISSION_GRANTED });
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M)
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AUDIO_PERM_REQUEST && permissions.length > 0
                && Manifest.permission.RECORD_AUDIO .equals(permissions[0]) && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            Log.i("flycast", "Record audio permission granted");
            SipEmulator sip = new SipEmulator();
            JNIdc.setupMic(sip);
        }
        else if (requestCode == STORAGE_PERM_REQUEST) {
            Log.i("flycast", "External storage permission granted");
            storagePermissionGranted = true;
            setStorageDirectories();
            if (pendingIntentUrl != null) {
                JNIdc.setGameUri(pendingIntentUrl);
                pendingIntentUrl = null;
            }

            //setup mic
            if (InputDeviceManager.isMicPluggedIn())
                requestRecordAudioPermission();
        }

    }

    private String getDefaultHomeDir() {
        File dir = getExternalFilesDir(null);
        if (dir == null)
            dir = getFilesDir();
        return dir.getAbsolutePath();
    }

    // Called from native code
    public void onGameStateChange(boolean started) {
        runOnUiThread(new Runnable() {
            public void run() {
                if (started) {
                    gameStartedOnce = true;
                    startSplashWatch();
                }
                if (started)
                    getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else
                    getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        switch (requestCode)
        {
            case AndroidStorage.ADD_STORAGE_ACTIVITY_REQUEST:
                storage.onAddStorageResult(data);
                break;
            case AndroidStorage.IMPORT_HOME_ACTIVITY_REQUEST:
                storage.onImportHomeResult(data);
                break;
            case AndroidStorage.EXPORT_HOME_ACTIVITY_REQUEST:
                storage.onExportHomeResult(data);
                break;
            case PICK_GAME_FILES:
                onGameFilesPicked(resultCode, data);
                break;
        }
    }

    // ---- Single-game wrapper: The House of the Dead 2 (NAOMI, romset "hotd2") ----
    private static final String GAME_ROM = "hotd2.zip";
    private static final String GAME_BIOS = "hod2bios.zip";
    private static final int PICK_GAME_FILES = 7001;
    private String gameHome;

    private File gameRom() {
        return new File(gameHome, GAME_ROM);
    }

    private File gameBios() {
        return new File(new File(gameHome, "data"), GAME_BIOS);
    }

    // ---- startup splash (covers the native "Starting..." screen) ----
    private ImageView splash;
    private boolean splashWanted = false;
    private boolean gameStartedOnce = false;
    private final Runnable splashFailsafe = new Runnable() {
        public void run() { hideSplash(); }
    };

    protected void showSplashIfWanted() {
        if (!splashWanted || splash != null || gameStartedOnce)
            return;
        try {
            splash = new ImageView(this);
            splash.setBackgroundColor(0xFF000000);
            splash.setScaleType(ImageView.ScaleType.CENTER_CROP);
            splash.setImageResource(R.drawable.hotd2_splash);
            splash.setClickable(true);   // swallow touches while splash is up
            addContentView(splash, new ViewGroup.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            handler.postDelayed(splashFailsafe, 15000);
        } catch (Throwable t) {
            Log.e("flycast", "splash failed", t);
            splash = null;
        }
    }

    // Keep the splash up until the game surface really shows a bright frame
    // (the native "Starting..." box is almost black), then fade it out.
    private int splashHits = 0;
    private long splashWatchStart = 0;
    private final Runnable splashPoll = new Runnable() {
        public void run() { pollSplash(); }
    };

    private void startSplashWatch() {
        if (splash == null)
            return;
        splashHits = 0;
        splashWatchStart = SystemClock.uptimeMillis();
        handler.removeCallbacks(splashPoll);
        handler.postDelayed(splashPoll, 300);
    }

    private SurfaceView findSurface(View v) {
        if (v instanceof SurfaceView)
            return (SurfaceView) v;
        if (v instanceof ViewGroup) {
            ViewGroup g = (ViewGroup) v;
            for (int i = 0; i < g.getChildCount(); i++) {
                SurfaceView r = findSurface(g.getChildAt(i));
                if (r != null)
                    return r;
            }
        }
        return null;
    }

    @SuppressLint("NewApi")
    private void pollSplash() {
        if (splash == null)
            return;
        final long waited = SystemClock.uptimeMillis() - splashWatchStart;
        final SurfaceView sv = findSurface(getWindow().getDecorView());
        if (sv == null || Build.VERSION.SDK_INT < 24 || sv.getWidth() <= 0 || sv.getHeight() <= 0) {
            if (waited > 3000)
                hideSplash();
            else
                handler.postDelayed(splashPoll, 300);
            return;
        }
        final int W = 64, H = 28;
        final Bitmap bmp = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888);
        try {
            PixelCopy.request(sv, bmp, new PixelCopy.OnPixelCopyFinishedListener() {
                @Override
                public void onPixelCopyFinished(int result) {
                    if (splash == null)
                        return;
                    boolean frame = false;
                    if (result == PixelCopy.SUCCESS) {
                        int[] px = new int[W * H];
                        bmp.getPixels(px, 0, W, 0, 0, W, H);
                        int bright = 0;
                        for (int p : px) {
                            int lum = (((p >> 16) & 0xFF) * 3 + ((p >> 8) & 0xFF) * 6 + (p & 0xFF)) / 10;
                            if (lum > 40)
                                bright++;
                        }
                        frame = bright * 100 / (W * H) >= 15;
                    }
                    splashHits = frame ? splashHits + 1 : 0;
                    long w = SystemClock.uptimeMillis() - splashWatchStart;
                    if (splashHits >= 2 || w > 12000)
                        hideSplash();
                    else
                        handler.postDelayed(splashPoll, 250);
                }
            }, handler);
        } catch (Throwable t) {
            if (waited > 3000)
                hideSplash();
            else
                handler.postDelayed(splashPoll, 300);
        }
    }

    protected void hideSplash() {
        splashWanted = false;
        handler.removeCallbacks(splashFailsafe);
        handler.removeCallbacks(splashPoll);
        final ImageView v = splash;
        if (v == null)
            return;
        splash = null;
        v.animate().alpha(0f).setDuration(400).withEndAction(new Runnable() {
            public void run() {
                if (v.getParent() instanceof ViewGroup)
                    ((ViewGroup) v.getParent()).removeView(v);
            }
        }).start();
    }

    private void autoBoot(String homeDir) {
        gameHome = homeDir;
        if (gameRom().exists() && gameBios().exists()) {
            splashWanted = true;
            JNIdc.setGameUri(gameRom().getAbsolutePath());
        } else
            pickGameFiles();
    }

    private void pickGameFiles() {
        android.widget.Toast.makeText(this, "Select " + GAME_ROM + " and " + GAME_BIOS,
                android.widget.Toast.LENGTH_LONG).show();
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        startActivityForResult(i, PICK_GAME_FILES);
    }

    private String displayName(Uri uri) {
        try (android.database.Cursor c = getContentResolver().query(uri, null, null, null, null)) {
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME);
                if (idx >= 0)
                    return c.getString(idx);
            }
        } catch (Exception e) {
            Log.w("flycast", "displayName failed", e);
        }
        return null;
    }

    private void copyUri(Uri uri, File dest) throws java.io.IOException {
        File dir = dest.getParentFile();
        if (dir != null && !dir.exists())
            dir.mkdirs();
        File tmp = new File(dest.getPath() + ".tmp");
        try (java.io.InputStream in = getContentResolver().openInputStream(uri);
             java.io.OutputStream out = new java.io.FileOutputStream(tmp)) {
            if (in == null)
                throw new java.io.IOException("Cannot open " + uri);
            byte[] buf = new byte[1 << 16];
            int n;
            while ((n = in.read(buf)) > 0)
                out.write(buf, 0, n);
        }
        if (dest.exists())
            dest.delete();
        if (!tmp.renameTo(dest))
            throw new java.io.IOException("Cannot write " + dest);
    }

    private void onGameFilesPicked(int resultCode, Intent data) {
        final List<Uri> uris = new ArrayList<>();
        if (resultCode == Activity.RESULT_OK && data != null) {
            if (data.getClipData() != null) {
                for (int i = 0; i < data.getClipData().getItemCount(); i++)
                    uris.add(data.getClipData().getItemAt(i).getUri());
            } else if (data.getData() != null) {
                uris.add(data.getData());
            }
        }
        new Thread(() -> {
            for (Uri uri : uris) {
                String name = displayName(uri);
                try {
                    if (GAME_ROM.equalsIgnoreCase(name))
                        copyUri(uri, gameRom());
                    else if (GAME_BIOS.equalsIgnoreCase(name))
                        copyUri(uri, gameBios());
                } catch (java.io.IOException e) {
                    Log.e("flycast", "Copy failed for " + name, e);
                }
            }
            handler.post(() -> {
                if (gameRom().exists() && gameBios().exists()) {
                    splashWanted = true;
                    showSplashIfWanted();
                    JNIdc.setGameUri(gameRom().getAbsolutePath());
                } else {
                    android.widget.Toast.makeText(this, "Missing " + GAME_ROM + " or " + GAME_BIOS,
                            android.widget.Toast.LENGTH_LONG).show();
                    pickGameFiles();
                }
            });
        }).start();
    }

    private static native void register(BaseGLActivity activity);
    
	public String getNativeLibDir() {
        return getApplicationContext().getApplicationInfo().nativeLibraryDir;
    }
    
	public String getInternalFilesDir() {
        return getFilesDir().getAbsolutePath();
    }
}
